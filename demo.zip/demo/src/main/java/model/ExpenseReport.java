package model;

import java.io.Serializable;
import java.util.Map;

public class ExpenseReport implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ExpenseReport(Map<String, Integer> map, int total, int average) {
		super();
		this.map = map;
		this.total = total;
		this.average = average;
	}
	private Map<String, Integer> map;
	private int total;
	private int average;
	public Map<String, Integer> getMap() {
		return map;
	}
	public void setMap(Map<String, Integer> map) {
		this.map = map;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getAverage() {
		return average;
	}
	public void setAverage(int average) {
		this.average = average;
	}
	
	
}
