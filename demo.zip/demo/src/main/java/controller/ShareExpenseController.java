package controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import model.ExpenseDetails;
import model.ExpenseReport;
import model.Group;
import model.Person;
import model.TotalExpenseRequest;
import services.ShareExpenseServiceInterface;

@RestController
@RequestMapping("/shareExpense")
public class ShareExpenseController {

	@Autowired
	private ShareExpenseServiceInterface service;
	
	@PostMapping(path= "/addExpense", consumes = "application/json", produces = "application/json")
    public ResponseEntity<ExpenseDetails> addExpense(@RequestParam(value="expense") ExpenseDetails expenseDetail) {
		
		boolean expense = service.addExpense(expenseDetail);
		return new ResponseEntity<>(HttpStatus.ACCEPTED);
    }
	
	@PostMapping(path= "/editExpense", consumes = "application/json", produces = "application/json")
    public ResponseEntity<ExpenseDetails> editExpense(@RequestParam(value="expense") ExpenseDetails expenseDetail) {
		boolean expense = service.updateExpense(expenseDetail);
		return new ResponseEntity<>(HttpStatus.ACCEPTED);
    }
	
	@PostMapping(path= "/removeExpense", consumes = "application/json", produces = "application/json")
    public ResponseEntity<ExpenseDetails> removeExpense(@RequestParam(value="expense") ExpenseDetails expenseDetail) {
		boolean expense = service.removeExpense(expenseDetail);
		return new ResponseEntity<>(HttpStatus.ACCEPTED);
    }
	
	@PostMapping(path= "/getTotalExpense", consumes = "application/json", produces = "application/json")
    public ResponseEntity<ExpenseDetails> getTotalExpense(@RequestParam(value="totalExpenseRequest") TotalExpenseRequest totalExpenseRequest) {
		ExpenseDetails expense = service.getTotalExpense(totalExpenseRequest);
		return new ResponseEntity<>(expense, HttpStatus.ACCEPTED);
    }
	
	@PostMapping(path= "/getExpenseReport", consumes = "application/json", produces = "application/json")
    public ResponseEntity<ExpenseReport> getExpenseReport(@RequestParam(value="totalExpenseRequest") TotalExpenseRequest totalExpenseRequest) {
		ExpenseReport expense = service.getExpenseReport(totalExpenseRequest);
		return new ResponseEntity<>(expense, HttpStatus.ACCEPTED);
    }
	
	@PostMapping(path= "/addGroup", consumes = "application/json", produces = "application/json")
    public ResponseEntity<Group> addGroup(@RequestParam(value="name", defaultValue="World") Group group) {
		Group groupRes = service.addGroup(group);
		return new ResponseEntity<>(groupRes, HttpStatus.ACCEPTED);
    }
	
	@PostMapping(path= "/removeGroup", consumes = "application/json", produces = "application/json")
    public ResponseEntity<Group> removeGroup(@RequestParam(value="name", defaultValue="World") Group group) {
		Group groupRes = service.removeGroup(group);
		return new ResponseEntity<>(groupRes, HttpStatus.ACCEPTED);
    }
	
	@PostMapping(path= "/addPerson", consumes = "application/json", produces = "application/json")
    public ResponseEntity<Person> addPerson(@RequestParam(value="name", defaultValue="World") Person person) {
		Person personRes = service.addPerson(person);
		return new ResponseEntity<>(personRes, HttpStatus.ACCEPTED);
    }
	
	@PostMapping(path= "/removePerson", consumes = "application/json", produces = "application/json")
    public ResponseEntity<Person> removePerson(@RequestParam(value="name", defaultValue="World") Person person) {
		Person personRes = service.removePerson(person);
		return new ResponseEntity<>(personRes, HttpStatus.ACCEPTED);
    }
	
}
