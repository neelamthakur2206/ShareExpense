package services;

import model.ExpenseDetails;
import model.ExpenseReport;
import model.Group;
import model.Person;
import model.TotalExpenseRequest;

public interface ShareExpenseServiceInterface {
	public boolean addExpense(ExpenseDetails expenseDetail);
	public boolean removeExpense(ExpenseDetails expenseDetail);
	public boolean updateExpense(ExpenseDetails expenseDetail);
	public ExpenseReport getExpenseReport(TotalExpenseRequest totalExpenseRequest);
	public ExpenseDetails getTotalExpense(TotalExpenseRequest totalExpenseRequest);
	public Group addGroup(Group group);
	public Group removeGroup(Group group);
	public Person addPerson(Person person);
	public Person removePerson(Person person);
}
