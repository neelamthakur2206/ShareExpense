package services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dao.ShareExpenseRepoInterface;
import model.ExpenseDetails;
import model.ExpenseReport;
import model.Group;
import model.Person;
import model.TotalExpenseRequest;

@Service
public class ShareExpenseService implements ShareExpenseServiceInterface{

	@Autowired
	private ShareExpenseRepoInterface repository;
	
	@Override
	public boolean addExpense(ExpenseDetails expenseDetail) {
		boolean expense = repository.addExpense(expenseDetail);
		return expense;
	}

	@Override
	public boolean removeExpense(ExpenseDetails expenseDetail) {
		boolean expense = repository.removeExpense(expenseDetail);
		return expense;
	}

	@Override
	public boolean updateExpense(ExpenseDetails expenseDetail) {
		boolean expense = repository.updateExpense(expenseDetail);
		return expense;
	}

	@Override
	public ExpenseReport getExpenseReport(TotalExpenseRequest totalExpenseRequest) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ExpenseDetails getTotalExpense(TotalExpenseRequest totalExpenseRequest) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Group addGroup(Group group) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Group removeGroup(Group group) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Person addPerson(Person person) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Person removePerson(Person person) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
