package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import model.ExpenseDetails;
import model.ExpenseReport;
import model.Group;
import model.Person;
import model.TotalExpenseRequest;
import utils.ShareExpenseUtils;

@Repository
public class ShareExpenseRepository implements ShareExpenseRepoInterface{

	private List<Person> personList = new ArrayList<Person>();
	private List<Group> groupList = new ArrayList<Group>();
	private List<ExpenseDetails> expenseList = new ArrayList<ExpenseDetails>();
	
	@Override
	public boolean addExpense(ExpenseDetails expense) {
		// TODO Auto-generated method stub
		boolean flag = expenseList.add(expense);
		return flag;
	}

	@Override
	public boolean removeExpense(ExpenseDetails expense) {
		ExpenseDetails exp = expenseList.stream().filter((ex)-> ex.getGroup() == expense.getGroup()).filter((ex)-> ex.getPerson() == expense.getPerson()).filter((ex)-> ex.getStartDate() == expense.getStartDate()).findFirst()
                .get();
		boolean flag = expenseList.remove(exp);	
		return flag;
	}

	@Override
	public boolean updateExpense(ExpenseDetails expense) {
		
		ExpenseDetails exp = expenseList.stream().filter((ex)-> ex.getGroup() == expense.getGroup()).filter((ex)-> ex.getPerson() == expense.getPerson()).filter((ex)-> ex.getStartDate() == expense.getStartDate()).findFirst()
                .get();
		expenseList.remove(exp);
		
		//add updated expense details
		boolean flag = expenseList.add(expense);
		return flag;
	}

	@Override
	public ExpenseReport getExpenseAverage(TotalExpenseRequest expenseRequest) {
		// TODO Auto-generated method stub
		List<ExpenseDetails> exp = expenseList.stream().filter((ex)-> ex.getGroup() == expenseRequest.getGroup()).filter((ex)-> ex.getStartDate() == expenseRequest.getStartDate()).collect(Collectors.toList());
		
		int total = exp.stream().map(x -> x.getAmount()).reduce(0, Integer::sum);
		
		List<String> distinctList = exp.stream().distinct().map(e-> e.getPerson()).collect(Collectors.toList());
		int count = distinctList.size();
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		for(String person : distinctList){
			int personTotal = exp.stream().filter(p -> p.getPerson() == person).map(x -> x.getAmount()).reduce(0, Integer::sum);
			map.put(person, personTotal);
		}
		int average = total / count;

		ExpenseReport expReport = new ExpenseReport(map, total, average);
		return expReport;
	}

	@Override
	public int getTotalExpense(TotalExpenseRequest expenseRequest) {
		List<ExpenseDetails> exp = expenseList.stream().filter((ex)-> ex.getGroup() == expenseRequest.getGroup()).filter((ex)-> ex.getStartDate() == expenseRequest.getStartDate()).collect(Collectors.toList());
		
		int total = exp.stream().map(x -> x.getAmount()).reduce(0, Integer::sum);	
		return total;
	}

	@Override
	public Group addGroup(Group group) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Group removeGroup(Group group) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Person addPerson(Person person) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Person removePerson(Person person) {
		// TODO Auto-generated method stub
		return null;
	}

}
