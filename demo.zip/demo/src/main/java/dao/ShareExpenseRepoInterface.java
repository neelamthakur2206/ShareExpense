package dao;

import model.ExpenseDetails;
import model.ExpenseReport;
import model.Group;
import model.Person;
import model.TotalExpenseRequest;

public interface ShareExpenseRepoInterface {

	public boolean addExpense(ExpenseDetails expense);
	public boolean removeExpense(ExpenseDetails expense);
	public boolean updateExpense(ExpenseDetails expense);
	public ExpenseReport getExpenseAverage(TotalExpenseRequest request);
	public int getTotalExpense(TotalExpenseRequest request);
	public Group addGroup(Group group);
	public Group removeGroup(Group group);
	public Person addPerson(Person person);
	public Person removePerson(Person person);
	
}
